# APQ Thesis
ENGLISH Version [below](#Summary)

## Übersicht
In diesem Ordner liegt eine Beispieldatei für eine Thesis im APQ-Design. 

## Dateien
Die stets aktuellste Version ist als PDF [hier](../../../releases/latest) zu finden.

## Anmerkungen/Besonderheiten für APQ Thesis
1. package `ulem` ändert das Design des Literaturverzeichnisses bei Osa_Mod. Für durchstreichen kann cancel verwendet werden.
2. Für den Titel sind 3 Zeilen vorgesehen. Hat der Titel nur zwei Zeilen, ist ein Zeillenumbruch (`\\`) einzufügen, um den Titel oben bündig zu positionieren. Ist der Titel einzeilig sind zwei Freizeilen (`\\ \ \\`) anzuhängen.
3. Im OneSide Modus (bspw. Proposal) gibt es dennoch die Möglichkeit einer Titelrückseite für unter anderem eine Beschreibung des Titelbildes.
4. Für Bachelor- und Masterthesis ist der TwoSide Modus (twoside = true) vorgesehen, während das Thesisproposal einseitig ausgelegt ist (twoside = false)
5. Spracheinstellung: `\usepackage[main = ngerman,british]{babel}` legt die Hauptsprache für automatisch generierte Textbausteine fest. Bitte auch an die Anpassung im siunitx package denken.
6. Korrekte Zeichensetzung in Bezug auf die Einheiten aus dem [UTF-8](https://de.wikipedia.org/wiki/UTF-8) Zeichensatz wie z.B. µ oder Ω wird nur mit [LuaLaTeX](https://www.luatex.org/) (empfohlen) oder [XeLaTeX](https://texdoc.org/serve/xetexref/0) als Compiler erreicht. Das veraltete [pdfLaTeX](https://texdoc.org/serve/pdftex-a.pdf/0) erzeugt unschöne Resultate und wird nicht empfohlen.

## Summary
This folder contains the example file for a thesis in apq-style.

## Files
The latest version of the example PDF for theses in apq-style can be found [here](../../../releases/latest).

## Remarks/Special Features
1. package `ulem` changes style of Osa_mod. For striking through package cancel can be used.
2. For the title 3 lines are reserved. If the title has only two lines just add a empty line (`\\`) for correct positioning. If the title contains one line add two empty lines (`\\ \ \\`).
3. In mode oneside (e.g. project proposal) there is nevertheless a option for the titleback which contains for example a description of the title image.
4. For bachelor's and master's theses twoside mode (twoside = true) is recommended while thesis proposals are supposed to be written in oneside mode (twoside = false)
5. Language Setting: `\usepackage[ngerman,main = british]{babel}` sets the main language for the automatic generated text blocks (e.g. "by" vs. "von"). Please set the correct language as well for the siunitx package.
6. It has to be noted that correct typesetting of the templates only works using [LuaLaTeX](https://www.luatex.org/) (recommended) or [XeLaTeX](https://texdoc.org/serve/xetexref/0) as a compiler. Using the older [pdfLaTeX](https://texdoc.org/serve/pdftex-a.pdf/0) causes typesetting artifacts for units containing [UTF-8](https://en.wikipedia.org/wiki/UTF-8) symbols like µ or Ω.
